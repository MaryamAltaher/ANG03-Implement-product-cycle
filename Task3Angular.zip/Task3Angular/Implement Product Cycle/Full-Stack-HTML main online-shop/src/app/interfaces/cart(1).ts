import { CartLine } from './cart-line';

export interface Cart {
  cartLines: CartLine[];
}

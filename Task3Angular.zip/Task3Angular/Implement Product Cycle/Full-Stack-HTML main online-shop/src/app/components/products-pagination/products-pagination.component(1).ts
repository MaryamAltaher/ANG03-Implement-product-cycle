import { Component } from '@angular/core';

@Component({
  selector: 'app-products-pagination',
  templateUrl: './products-pagination.component.html',
  styleUrls: ['./products-pagination.component.css']
})
export class ProductsPaginationComponent {

}
